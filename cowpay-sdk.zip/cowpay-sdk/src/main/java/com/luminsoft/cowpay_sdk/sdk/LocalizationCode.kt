package com.luminsoft.cowpay_sdk.sdk

enum class LocalizationCode {
    AR,EN
}

